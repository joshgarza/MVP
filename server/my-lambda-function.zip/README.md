Command to update database tables
psql -U joshgarza -d trainer -a -f server/db/app.sql