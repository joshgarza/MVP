--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.7 (Homebrew)
-- Dumped by pg_dump version 14.7 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE coaching_app_postgres;
--
-- Name: coaching_app_postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE coaching_app_postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


ALTER DATABASE coaching_app_postgres OWNER TO postgres;

\connect coaching_app_postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: clientassignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clientassignments (
    client_id integer,
    coach_id integer
);


ALTER TABLE public.clientassignments OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    firebase_id character varying(40) NOT NULL,
    email character varying(320) NOT NULL,
    user_type character varying(25) NOT NULL,
    name character varying(100) NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: workoutresults; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workoutresults (
    id integer NOT NULL,
    client_id integer,
    coach_id integer,
    date character varying(100) NOT NULL,
    workout_order integer NOT NULL,
    exercise character varying(100) NOT NULL,
    exercise_order integer NOT NULL,
    set integer NOT NULL,
    reps integer,
    rir integer,
    rpe integer,
    backoff_percent integer,
    weight integer
);


ALTER TABLE public.workoutresults OWNER TO postgres;

--
-- Name: workoutresults_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.workoutresults_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.workoutresults_id_seq OWNER TO postgres;

--
-- Name: workoutresults_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.workoutresults_id_seq OWNED BY public.workoutresults.id;


--
-- Name: workouts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workouts (
    id integer NOT NULL,
    client_id integer,
    coach_id integer,
    date character varying(100) NOT NULL,
    workout_order integer NOT NULL,
    exercise character varying(100) NOT NULL,
    exercise_order integer NOT NULL,
    set integer NOT NULL,
    reps integer NOT NULL,
    rir integer,
    rpe integer,
    backoff_percent integer,
    weight integer
);


ALTER TABLE public.workouts OWNER TO postgres;

--
-- Name: workouts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.workouts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.workouts_id_seq OWNER TO postgres;

--
-- Name: workouts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.workouts_id_seq OWNED BY public.workouts.id;


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: workoutresults id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workoutresults ALTER COLUMN id SET DEFAULT nextval('public.workoutresults_id_seq'::regclass);


--
-- Name: workouts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workouts ALTER COLUMN id SET DEFAULT nextval('public.workouts_id_seq'::regclass);


--
-- Data for Name: clientassignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clientassignments (client_id, coach_id) FROM stdin;
\.
COPY public.clientassignments (client_id, coach_id) FROM '$$PATH$$/3616.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, firebase_id, email, user_type, name) FROM stdin;
\.
COPY public.users (id, firebase_id, email, user_type, name) FROM '$$PATH$$/3615.dat';

--
-- Data for Name: workoutresults; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workoutresults (id, client_id, coach_id, date, workout_order, exercise, exercise_order, set, reps, rir, rpe, backoff_percent, weight) FROM stdin;
\.
COPY public.workoutresults (id, client_id, coach_id, date, workout_order, exercise, exercise_order, set, reps, rir, rpe, backoff_percent, weight) FROM '$$PATH$$/3620.dat';

--
-- Data for Name: workouts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workouts (id, client_id, coach_id, date, workout_order, exercise, exercise_order, set, reps, rir, rpe, backoff_percent, weight) FROM stdin;
\.
COPY public.workouts (id, client_id, coach_id, date, workout_order, exercise, exercise_order, set, reps, rir, rpe, backoff_percent, weight) FROM '$$PATH$$/3618.dat';

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: workoutresults_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.workoutresults_id_seq', 4, true);


--
-- Name: workouts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.workouts_id_seq', 62, true);


--
-- Name: clientassignments clientassignments_client_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clientassignments
    ADD CONSTRAINT clientassignments_client_id_key UNIQUE (client_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: workoutresults workoutresults_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workoutresults
    ADD CONSTRAINT workoutresults_pkey PRIMARY KEY (id);


--
-- Name: workouts workouts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workouts
    ADD CONSTRAINT workouts_pkey PRIMARY KEY (id);


--
-- Name: clientassignments clientassignments_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clientassignments
    ADD CONSTRAINT clientassignments_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.users(id);


--
-- Name: clientassignments clientassignments_coach_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clientassignments
    ADD CONSTRAINT clientassignments_coach_id_fkey FOREIGN KEY (coach_id) REFERENCES public.users(id);


--
-- Name: workoutresults workoutresults_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workoutresults
    ADD CONSTRAINT workoutresults_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.users(id);


--
-- Name: workoutresults workoutresults_coach_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workoutresults
    ADD CONSTRAINT workoutresults_coach_id_fkey FOREIGN KEY (coach_id) REFERENCES public.users(id);


--
-- Name: workouts workouts_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workouts
    ADD CONSTRAINT workouts_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.users(id);


--
-- Name: workouts workouts_coach_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workouts
    ADD CONSTRAINT workouts_coach_id_fkey FOREIGN KEY (coach_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

